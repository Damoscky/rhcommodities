<div class="card-header">
  <img
    class="logo-img"
    src="<?php echo e(asset("images/rhc_logo.svg")); ?>"
    alt="RHC"
  />
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/rhc-commodities/resources/views/layouts/mail/header.blade.php ENDPATH**/ ?>