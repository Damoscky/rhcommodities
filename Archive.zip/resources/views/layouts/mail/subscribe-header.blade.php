<div class="card-header">
  <img
    class="logo-img"
    src="{{asset("images/header.svg")}}"
    alt="Optimus Bank"
  />
</div>
