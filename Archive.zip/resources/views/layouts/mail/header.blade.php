<div class="card-header">
  <img
    class="logo-img"
    src="{{asset("images/rhc_logo.svg")}}"
    alt="RHC"
  />
</div>
